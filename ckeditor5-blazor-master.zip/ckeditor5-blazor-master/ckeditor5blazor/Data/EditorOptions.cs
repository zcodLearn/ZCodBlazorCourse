using System;

namespace ckeditor5blazor.Data
{
    public class EditorOptions
    {
        public string InitialText { get; set; }
    }
}
